function ifAble(ch){
    if(ch>52){
      console.log("Get on ride.")
    }
    else{
      console.log("Maybe next year.")
    }
  }
  ifAble(56)