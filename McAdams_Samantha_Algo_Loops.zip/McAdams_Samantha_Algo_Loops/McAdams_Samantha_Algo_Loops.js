for (i = 1; i <= 20; i++) {
    if (i % 2 != 0) {
        console.log(i);
    }
}

log 1, 3, 5, 7, 9, 11, 13, 15, 17, 19

var sum = 0;
for (let i = 0; i < 5; i++) {
    sum += i
    console.log('num:', i, 'sum:', sum)
}

log
Num: 1, Sum: 1
Num: 2, Sum: 3
Num: 3, Sum: 6
Num: 4, Sum: 10
Num: 5, Sum: 15